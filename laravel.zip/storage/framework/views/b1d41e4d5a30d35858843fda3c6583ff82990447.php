<!DOCTYPE html>
<html lang="en">
<head>
<script
      type="text/javascript"
      src="//dapi.kakao.com/v2/maps/sdk.js?appkey=3072054af20a38676e15753395ad31d2&libraries=services,clusterer,drawing"
    ></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div id="app">
        <app><app>
    </div>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
</body>
</html><?php /**PATH C:\Users\user\Desktop\프로그래밍\github\auto_pilot\laravel\resources\views/welcome.blade.php ENDPATH**/ ?>