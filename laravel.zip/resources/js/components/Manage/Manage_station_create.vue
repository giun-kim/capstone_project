<template>
    <div>
        <b-col cols="3">
            <b-row> <!-- 등록 -->
                <p v-if="stage == 1">지도에서 원하는 위치를 클릭해 주세요.</p> 
                <div v-if="stage == 2">
                    <b-form>
                        <p>정류장 이름</p>
                        <b-form-input v-model="stn_name" placeholder="정류장을 입력해 주세요."></b-form-input>
                        <p>위도</p>
                        <p>{{ lat }}</p>
                        <p>경도</p>
                        <p>{{ lng }}</p>
                        <b-button type="submit" variant="primary" @click="stn_create()">등록하기</b-button>
                        <b-button type="button" @click="cancel()">취소하기</b-button>
                    </b-form>
                </div>
            </b-row>
        </b-col>
        <b-col cols="7">
            <div id="map" @click="map_click()"></div> 
        </b-col>
    </div>
</template>

<script>
import data from './data/station'
    export default {
        mounted() {
            if(data[this.length-1].stn_id != '') {
                this.data.push({
                    stn_id : '',
                    stn_name : '',
                    latlng : ''
                })
            } else if(data[this.length-1].stn_id == '') {
                data.splice(this.length-1, 1)
            }
            
            this.initMap()
        }, 
        data() {
            return {
                map_stage : 1, // 맵 한번만 생성
                stage : 1, // 단계별 보여지는 화면
                stn_name : '', // 정류장 이름
                lat : '', // 위도
                lng : '', // 경도
                data : data, // 정류장 데이터
                length : data.length, // 정류장 데이터 전체 길이
                stn_id : '', // 정류장 아이디
                latlng : '', // 위도, 경도
                map : ''
            } 
        },
        methods : {
            initMap() {
                if(this.map_stage == 1) {
                    var container = document.getElementById('map');
                    var options = {
                        center: new kakao.maps.LatLng(35.896309, 128.621917), 
                        level: 2,
                        draggable : false
                    };
                    var map = new kakao.maps.Map(container, options);
                    this.map = map
                }

                // 여러 개 마커 생성하기
                for (let i = 0; i < this.data.length; i++) {
                    // 마커를 생성합니다
                    var marker = new kakao.maps.Marker({
                        map : this.map,
                        position: data[i].latlng ? data[i].latlng : '', // 마커를 표시할 위치
                        title : data[i].stn_name ? data[i].stn_name : '',  // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다.
                    })
                }
    
                // 마커 표시
                kakao.maps.event.addListener(map, 'click', (mouseEvent) => { 
                   
                    // 클릭한 위도, 경도 정보를 가져옵니다 
                    let latlng = mouseEvent.latLng
        
                    // 마커 위치를 클릭한 위치로 옮깁니다
                    marker.setPosition(latlng)

                    this.lat = latlng.getLat()
                    this.lng = latlng.getLng()
                })
            },
            stn_create() {
                this.data[this.data.length-1].stn_id = this.data.length
                this.data[this.data.length-1].stn_name = this.stn_name
                this.data[this.data.length-1].latlng = new kakao.maps.LatLng(this.lat, this.lng)
                this.initialize()
                this.initMap()
            },
            cancel() {
                this.initialize() 
                this.initMap()
            },
            map_click() {
                 if(this.stage == 1)
                    this.stage +=1
            },
            initialize() {
                this.map_stage = 1, // 맵 한번만 생성
                this.stage = 1, // 단계별 보여지는 화면
                this.stn_name = '', // 정류장 이름
                this.lat = '', // 위도
                this.lng = '', // 경도
                this.data = data, // 정류장 데이터
                this.length = data.length, // 정류장 데이터 전체 길이
                this.stn_id = '', // 정류장 아이디
                this.latlng = '' // 위도, 경도
                if(data[this.length-1].stn_name != '') {
                    this.data.push({
                        stn_id : '',
                        stn_name : '',
                        latlng : ''
                    })
                } else if(data[this.length-1].stn_name == '') {
                    data.splice(this.length-1, 1)
                }
            }
        }
    }
</script>

<style scoped>
#map{
    width:50rem; 
    height:40rem;
}
</style>