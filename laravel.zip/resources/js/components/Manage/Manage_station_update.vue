<template>
    <div>
        {{ data }}
        {{ stage }}
        {{ stn_id }}
        <b-col cols="3">
            <b-row> <!-- 수정 -->
                <p v-if="stage == 1">지도에서 수정/삭제할 정류장을 클릭해 주세요.</p>
                <div v-if="stage == 2">
                    <b-form>
                        <p>정류장 이름</p>
                        <b-form-input v-model="stn_name" :placeholder="stn_name" ></b-form-input>
                        <p>위도</p>
                        <p id="lat">{{ lat }}</p>
                        <p>경도</p>
                        <p id="lng">{{ lng }}</p>
                        <b-button type="submit" variant="primary" @click="stn_update()">수정하기</b-button>
                        <b-button type="button" @click="stn_delete()">삭제하기</b-button>
                        <b-button type="button" @click="cancel()">취소하기</b-button>
                    </b-form>
                </div>
            </b-row>
        </b-col>
        <b-col cols="7">
            <div id="map" @click="map_click()"></div> 
        </b-col>
    </div>
</template>

<script>
import data from './data/station'
    export default {
        mounted() {
            this.initMap()
        }, 
        data() {
            return {
                map_stage : 1, // 맵 한번만 생성
                stage : 1, // 단계별 보여지는 화면
                stn_name : '', // 정류장 이름
                lat : '', // 위도
                lng : '', // 경도
                data : data, // 정류장 데이터
                length : data.length, // 정류장 데이터 전체 길이
                stn_id : -1, // 정류장 아이디 => 참고해서 데이터 가져옴
                markers : [], // 마커 표시
                latlng : '', // 위도, 경도
                map : '', // 맵 저장
                click : 0
            } 
        },
        methods : {
            initMap() { // 단 한번만 실행으로 모든 걸 처리
                if(this.map_stage == 1) {
                    var container = document.getElementById('map');
                    var options = {
                        center: new kakao.maps.LatLng(35.896309, 128.621917), // 지도 중심 좌표
                        level: 2, // 지도 확대
                        draggable : false // 지도 이동 막기
                    };
                    var map = new kakao.maps.Map(container, options);
                    this.map = map
                    this.map_stage = 2
                }

                // 여러 개 마커 생성하기
                if(this.stage == 1) {
                    for (let i = 0; i < this.data.length; i++) {
                        // 마커를 생성합니다
                        const marker = new kakao.maps.Marker({
                            position: this.data[i].latlng, // 마커를 표시할 위치
                            title : this.data[i].stn_name // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다.
                        })
                        marker.setMap(this.map)
                        this.markers.push(marker)
                        // console.log(marker)

                        kakao.maps.event.addListener(this.markers[i], 'click', () => { 
                            this.stage = 2 // 정류장 클릭 후 수정 페이지 이동
                            if(this.click == 0) {
                                this.click += 1
                                this.stn_id = i // 클릭해서 정류장 아이디 찾기
                                this.markers[this.stn_id].setDraggable(true)
                            }
                        })

                        kakao.maps.event.addListener(this.markers[i], 'dragged', () => {
                            console.log(this.markers[this.stn_id])
                            this.lat = this.markers[this.stn_id].getPosition().Ga
                            this.lng = this.markers[this.stn_id].getPosition().Ha
                        })  
                    }
                }
            },
            stn_delete() {
                data.splice(this.stn_id, 1)
                this.initialize()
            },
            stn_update() {
                data[this.stn_id].stn_name = this.stn_name
                data[this.stn_id].latlng = new kakao.maps.LatLng(this.lat, this.lng)
                this.initialize()
            },
            cancel() {
                this.initialize()
            },
            initialize() {
                this.map_stage = 2, // 맵 한번만 생성
                this.stage = 1, // 단계별 보여지는 화면
                this.stn_name = '', // 정류장 이름
                this.lat = '', // 위도
                this.lng = '', // 경도
                this.data = data, // 정류장 데이터
                this.length = data.length, // 정류장 데이터 전체 길이
                this.stn_id = 1, // 정류장 아이디
                this.markers = [], // 마커 표시
                this.latlng = '' // 위도, 경도
                this.click = 0
                this.map = ''
            },
            map_click() {
                if(this.stage == 2)
                    this.initMap()
            }
        },
        watch : {
            stn_id : function(stn_id) { // 수정 마커 클릭시 데이터 입력
                this.lng = this.data[stn_id].latlng.Ga
                this.lat = this.data[stn_id].latlng.Ha
                this.stn_name = this.data[stn_id].stn_name
            }
        }
    }
</script>

<style scoped>
#map{
    width:50rem; 
    height:40rem;
}
</style>