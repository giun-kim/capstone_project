export default [
    {
        stn_id : 1,
        stn_name : 'stn_1',
        latlng : new kakao.maps.LatLng(35.896705, 128.620973)
    },
    {
        stn_id : 2,
        stn_name : 'stn_2',
        latlng : new kakao.maps.LatLng(35.896713, 128.622046)
    },
    {
        stn_id : 3,
        stn_name : 'stn_3',
        latlng : new kakao.maps.LatLng(35.895331, 128.623376)
    }
]