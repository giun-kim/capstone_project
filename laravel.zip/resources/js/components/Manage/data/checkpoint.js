export default [
    {
        id : 1,
        latlng : new kakao.maps.LatLng(35.896705, 128.620973)
    },
    {
        id : 2,
        latlng : new kakao.maps.LatLng(35.896713, 128.622046)
    },
    {
        id : 3,
        latlng : new kakao.maps.LatLng(35.895331, 128.623376)
    },
]