<template>
    <div>
        나는 관리 페이지
    </div>
</template>

<script>
    export default {

    }
</script>