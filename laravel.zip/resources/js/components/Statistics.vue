<template>
    <div>
        나는 통계 페이지
    </div>
</template>

<script>
export default {

}
</script>

<style>

</style>